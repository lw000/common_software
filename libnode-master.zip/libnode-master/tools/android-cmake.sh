#!/bin/sh
# export ANDROID_NDK=/path/to/android-ndk
deps/libj/tools/android-cmake.sh $@
