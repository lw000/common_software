#!/bin/sh
re2c -i --case-insensitive include/libnode/detail/http/header_scanner.re > include/libnode/detail/http/header_scanner.h
