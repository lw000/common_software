#!/bin/sh
deps/libj/tools/ios-cmake.sh $@
