powershell -File ./deps/libj/tools/windows-cmake.ps1 @args
