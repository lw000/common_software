// Copyright (c) 2013 Plenluno All rights reserved.

#ifndef LIBNODE_JSDP_H_
#define LIBNODE_JSDP_H_

#include <libnode/jsdp/discovery_service.h>

#endif  // LIBNODE_JSDP_H_
