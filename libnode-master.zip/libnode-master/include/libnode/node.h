// Copyright (c) 2012 Plenluno All rights reserved.

#ifndef LIBNODE_NODE_H_
#define LIBNODE_NODE_H_

namespace libj {
namespace node {

void run();

}  // namespace node
}  // namespace libj

#endif  // LIBNODE_NODE_H_
