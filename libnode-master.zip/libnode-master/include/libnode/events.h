// Copyright (c) 2012 Plenluno All rights reserved.

#ifndef LIBNODE_EVENTS_H_
#define LIBNODE_EVENTS_H_

#include <libnode/events/event_emitter.h>

#endif  // LIBNODE_EVENTS_H_
